package com.example.uas

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas.data.AppDatabase
import com.example.uas.data.entity.Dataset
import com.example.uas.data.entity.DatasetColumn
import com.example.uas.ui.theme.UASTheme

class EditDataset : ComponentActivity() {
    private val db by lazy { AppDatabase.getDatabase(this) }
    private val unifiedViewModel: UnifiedViewModel by viewModels { UnifiedViewModelFactory(db) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val datasetId = intent.getIntExtra("datasetId", -1)
        setContent {
            UASTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    EditDatasetScreen(unifiedViewModel, datasetId)
                }
            }
        }
    }
}

@Composable
fun EditDatasetScreen(viewModel: UnifiedViewModel, datasetId: Int) {
    val context = LocalContext.current
    val datasetWithColumns = viewModel.getDatasetWithColumnsById(datasetId)
    val namaDataset = remember { mutableStateOf("") }
    val deskripsiDataset = remember { mutableStateOf("") }
    val columns = remember { mutableStateListOf<DatasetColumn>() }

    LaunchedEffect(datasetWithColumns) {
        datasetWithColumns?.let {
            namaDataset.value = it.dataset.namaDataset
            deskripsiDataset.value = it.dataset.deskripsiDataset
            columns.clear()
            columns.addAll(it.columns)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF8DA7A8))
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Text(
                        text = "Edit Dataset",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = namaDataset.value,
                        onValueChange = { newValue -> namaDataset.value = newValue },
                        label = { Text("Nama Dataset") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )

                    OutlinedTextField(
                        value = deskripsiDataset.value,
                        onValueChange = { newValue -> deskripsiDataset.value = newValue },
                        label = { Text("Deskripsi Dataset") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }

                items(columns) { column ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .background(Color.White)
                            .padding(16.dp)
                    ) {
                        var namaKolom by remember { mutableStateOf(column.namaKolom) }
                        var tipeData by remember { mutableStateOf(column.tipeData) }

                        OutlinedTextField(
                            value = namaKolom,
                            onValueChange = { newValue -> namaKolom = newValue },
                            label = { Text("Nama Kolom") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        )

                        OutlinedTextField(
                            value = tipeData,
                            onValueChange = { newValue -> tipeData = newValue },
                            label = { Text("Tipe Data") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        )

                        LaunchedEffect(namaKolom, tipeData) {
                            columns[columns.indexOf(column)] = DatasetColumn(column.id, column.datasetId, namaKolom, tipeData)
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                columns.add(DatasetColumn(0, datasetId, "", ""))
                            },
                            modifier = Modifier.padding(8.dp),
                        ) {
                            Text("Tambah Kolom")
                        }

                        Button(
                            onClick = {
                                // Save the updated data to Room
                                val dataset = Dataset(
                                    id = datasetId,
                                    namaDataset = namaDataset.value,
                                    deskripsiDataset = deskripsiDataset.value
                                )
                                viewModel.updateDataset(dataset, columns)

                                // Show confirmation Toast
                                Toast.makeText(
                                    context,
                                    "Data berhasil diupdate",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            modifier = Modifier.padding(8.dp),
                        ) {
                            Text("Simpan")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            // Handle back navigation
                            val intent = Intent(context, Dataaset::class.java)
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Kembali", color = Color.White)
                    }
                }
            }
        }
    }
}